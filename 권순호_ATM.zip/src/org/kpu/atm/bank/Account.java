package org.kpu.atm.bank;

public class Account {
	private int nID; // ���� ��ȣ
	private int nBalance; // ���� �ܰ�
	private String strAccountName; // ���� ��
	private String strPassword; // ���� ��й�ȣ
	public Account(int id, int money, String name, String password) { // ������
		this.nID=id;
		this.nBalance=money;
		this.strAccountName=name;
		this.strPassword=password;
	}
	boolean authenticate(int id, String passwd) { // ���� Ȯ��
		if(id==this.nID && passwd.equals(this.strPassword)) {
			return true;
		}
		else {
			return false;
		}
	}
	public int getnID() {
		return nID;
	}
	public String getpassword() {
		return strPassword;
	}
	public int getnBalance() {
		return nBalance;
	}
	public int deposit(int money) {
		this.nBalance+=money;
		return nBalance;
	}
	public int widraw(int money) {	
		this.nBalance-=money;
		return nBalance;
	}
	public boolean updatePasswd(String oldPasswd, String newPasswd) {
		if(oldPasswd.equals(newPasswd)) {
			return false;
		}
		else {
			this.strPassword=newPasswd;
			return true;
		}
	}
	public String getAccountName() {
		return strAccountName;
	}
}
