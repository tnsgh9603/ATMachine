// statistics.java
package org.kpu.atm.util;

import org.kpu.atm.bank.*;

public class Statistics {
	static void swap(Account[] c, int idx1, int idx2) { 
		Account t = c[idx1]; 
		c[idx1] = c[idx2];
		c[idx2] = t; 
	}
	public static int sum(Account [] account, int size) {
		int sum = 0;
		for(int i=0;i<size;i++) {
			sum += account[i].getnBalance();
		}
		return sum;
	}
	public static double average(Account [] account, int size) {
		int sum = 0;
		try{
			for(int i=0;i<size;i++) {
				sum += account[i].getnBalance();
			}
			double ave= sum/size;
			return ave;
		}
		catch(ArithmeticException e) {
			return 0;
		}
	}
	public static int max(Account [] account, int size) {
		int max=0;
		for(int i=0;i<size;i++) {
			if(max < account[i].getnBalance()) {
				max = account[i].getnBalance();
			}
		}
		return max;
	}
	public static Account [] sort(Account [] account, int size) {
		Account[] b = new Account[size];
		Account[] c = new Account[size];
		for (int i = 0; i < size; i++) {
			b[i] = account[i];
			c[i] = account[i];
		}
		for(int k=0;k< size;k++) {
			for(int t=0;k+t< size;t++) {
				if(b[k].getnBalance() < b[k+t].getnBalance()) {
					c[k]= b[k];
					b[k]= b[k+t];
					b[k+t] = c[k];
				}
			}
		}
		return b;
	}
}
